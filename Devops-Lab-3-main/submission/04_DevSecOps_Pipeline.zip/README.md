# Lab 3: Monitoring, Logging & DevSecOps
**Student Name:** Rohit Raj  
**Roll No / Register No:** 2301730179  
**Email:** rajrajrohit2004@gmail.com  
**Course Activity:** Lab 3: Monitoring, Logging & DevSecOps  
**Date:** November 04, 2026  

## Question 4: Integrate Security into the CI/CD Pipeline (DevSecOps)
**Marks:** 5 Marks

### Overview
This package demonstrates the implementation of DevSecOps security practices integrated into a continuous delivery pipeline (GitHub Actions). It incorporates automated testing, dependency vulnerability scanning, static application security testing (SAST), and container filesystem analysis.

### Security Controls Implemented
1. **Dependency Vulnerability Scanning (`pip-audit`):**
   Scans application dependencies in `app/requirements.txt` against known CVE vulnerabilities in PyPI advisory databases. Fails on known exploits.
2. **Static Application Security Testing (SAST - `Semgrep`):**
   Executes `p/security-audit` rule pack across application and test code to identify security misconfigurations, credential leaks, and unsafe code patterns.
3. **Container Filesystem Vulnerability Scanning (`Trivy`):**
   Scans workspace and container definitions for HIGH and CRITICAL vulnerabilities with exit code 1 enforcement.
4. **Least-Privilege Container Hardening:**
   Application Dockerfile configures and switches to a dedicated unprivileged system user (`appuser` with UID 10001), preventing root privilege escalation.

### CI/CD Workflow (`.github/workflows/devsecops.yml`)
- Triggered on `push` and `pull_request`.
- Uses least-privilege `contents: read` token permissions.
- Executes Selenium E2E tests, pip-audit, Semgrep, and Trivy sequentially.

### Commands Executed
```bash
# 1. Dependency scanning
pip-audit -r app/requirements.txt

# 2. Static security scan
semgrep --config p/security-audit app/ tests/

# 3. Filesystem scan with Trivy
docker run --rm -v ${PWD}:/src aquasec/trivy:latest fs --severity HIGH,CRITICAL /src
```

### Observations
- Zero known CVEs in pinned application packages (`Flask==3.0.3`, `prometheus-client==0.20.0`, `gunicorn==22.0.0`).
- Semgrep passed with 0 blocking security issues.
- Trivy verified zero High or Critical vulnerabilities across the project filesystem.
