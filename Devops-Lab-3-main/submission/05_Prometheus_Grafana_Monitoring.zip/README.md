# Lab 3: Monitoring, Logging & DevSecOps
**Student Name:** Rohit Raj  
**Roll No / Register No:** 2301730179  
**Email:** rajrajrohit2004@gmail.com  
**Course Activity:** Lab 3: Monitoring, Logging & DevSecOps  
**Date:** November 04, 2026  

## Question 5: Set Up Monitoring Using Prometheus & Visualize in Grafana
**Marks:** 5 Marks

### Overview
This package implements full-stack operational monitoring using Prometheus for metrics collection and Grafana for visual telemetry dashboards.

### Architecture & Key Components
- `app/app.py`: Exposes Prometheus metrics at `/metrics` using `prometheus_client`:
  - `demo_http_requests_total`: Counter partitioned by method, path, status.
  - `demo_http_request_duration_seconds`: Histogram measuring response latency per path.
  - `demo_feature_greeting_v2_enabled`: Gauge reflecting active feature flag state.
- `observability/prometheus/prometheus.yml`: Configures 15s scrape interval targeting both `prometheus:9090` and `demo-app:8080`.
- `observability/grafana/provisioning/datasources/prometheus.yml`: Automatically provisions Prometheus as the default datasource.
- `observability/grafana/provisioning/dashboards/`: Auto-loads the "Demo Application Overview" dashboard (`demo-app.json`).
- `evidence/05-grafana-dashboard.png`: Grafana dashboard screenshot during load generation showing throughput (~8.64 req/s), path distribution, and latency.

### Commands Executed
```bash
# 1. Start application and monitoring stack
docker compose up -d demo-app prometheus grafana

# 2. Verify Prometheus scrape target
curl http://localhost:9090/api/v1/targets

# 3. Access Grafana Dashboard
# URL: http://localhost:3000 (admin / admin)
# Dashboard: Demo Application Overview
```

### Observations
- Metrics are collected with zero data loss across concurrent requests.
- The Grafana dashboard visualizes real-time throughput spikes during traffic generation and cleanly breaks down traffic across endpoints (`/`, `/api/status`, `/api/log-demo`).
