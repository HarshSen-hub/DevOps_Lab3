# Lab 3: Monitoring, Logging & DevSecOps
**Student Name:** Rohit Raj  
**Roll No / Register No:** 2301730179  
**Email:** rajrajrohit2004@gmail.com  
**Course Activity:** Lab 3: Monitoring, Logging & DevSecOps  
**Date:** November 04, 2026  

## Question 3: Implement Centralized Logging (ELK Stack)
**Marks:** 5 Marks

### Overview
This package contains the complete centralized logging architecture using Elasticsearch, Logstash, Kibana, and Filebeat (ELK Stack) integrated with a containerized Flask demo application emitting structured JSON logs.

### Architecture & Pipeline Flow
`Flask Application (JSON stdout) -> Filebeat (container log harvest) -> Logstash (port 5044 JSON filter) -> Elasticsearch (port 9200) -> Kibana (port 5601 Discover & Dashboards)`

- `docker-compose.yml`: Defines the entire stack including Elasticsearch, Logstash, Kibana, Filebeat, and demo-app.
- `logging/filebeat/filebeat.yml`: Reads container log files from `/var/lib/docker/containers/*/*.log`, appends Docker metadata, and streams to Logstash.
- `logging/logstash/pipeline/logstash.conf`: Filters logs for container name `demo-app`, extracts the `app_event` JSON payload, normalizes `@timestamp`, annotates with `pipeline: lab3-centralized-logging`, and routes to index `lab3-logs-%{+YYYY.MM.dd}`.
- `app/app.py`: Implements custom `JsonFormatter` emitting ISO 8601 timestamps, severity levels, service names, and event tags.
- `evidence/03-kibana-logs.png`: Kibana Discover view showing structured logs filtered by `app_event.event: "lab_log_demo"`.

### Commands Executed
```bash
# 1. Start logging stack
docker compose up -d --build

# 2. Emit structured log events
curl http://localhost:8080/api/log-demo

# 3. Verify in Kibana Discover
# URL: http://localhost:5601/app/discover
# Filter: app_event.event : "lab_log_demo"
```

### Observations
- Application logs are parsed instantaneously from JSON strings into structured queryable document fields.
- Kibana Discover clearly presents fields: `@timestamp`, `app_event.service`, `app_event.level`, `app_event.message`, and Docker container labels.
