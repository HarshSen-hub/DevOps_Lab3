# Lab 3: Monitoring, Logging & DevSecOps
**Student Name:** Rohit Raj  
**Roll No / Register No:** 2301730179  
**Email:** rajrajrohit2004@gmail.com  
**Course Activity:** Lab 3: Monitoring, Logging & DevSecOps  
**Date:** November 04, 2026  

## Question 7: Monitoring, Logging, and DevSecOps Comprehensive Report
**Marks:** 10 Marks

This package contains the complete laboratory documentation report for Lab 3 in PDF and Microsoft Word (.docx) formats, complete with system architecture, implementation details, command logs, execution evidence screenshots, and operational analysis.

### Files Included:
- `07_Monitoring_Logging_DevSecOps_Report.pdf`: 9-page formal laboratory report with embedded photographic evidence.
- `07_Monitoring_Logging_DevSecOps_Report.docx`: Editable Microsoft Word document format.
- `evidence/`: High-resolution screenshots of all 6 laboratory experiments.
- `report_sources/`: Python source scripts used to generate the report documents.
